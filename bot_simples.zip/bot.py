import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# Configurar logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Token do Telegram (SUBSTITUA PELO SEU TOKEN)
TOKEN = "8538748627:AAGaOYs-V17YITSPENRWWPTJSvVY4ZssCos"

# Base de dados dos jogos
JOGOS = {
    "tottenham x liverpool": {
        "liga": "Premier League", "data": "20/12/2025",
        "casa": {"nome": "Tottenham", "gols_casa": 2.0, "gols_fora": 1.4, "cantos": 5.8},
        "fora": {"nome": "Liverpool", "gols_casa": 2.5, "gols_fora": 1.8, "cantos": 6.0},
        "over25": 70, "btts": 62, "prob_casa": 28, "prob_empate": 24, "prob_fora": 48
    },
    "man city x west ham": {
        "liga": "Premier League", "data": "20/12/2025",
        "casa": {"nome": "Man City", "gols_casa": 2.8, "gols_fora": 2.0, "cantos": 7.2},
        "fora": {"nome": "West Ham", "gols_casa": 1.4, "gols_fora": 1.0, "cantos": 4.0},
        "over25": 72, "btts": 55, "prob_casa": 75, "prob_empate": 15, "prob_fora": 10
    },
    "real madrid x sevilla": {
        "liga": "LaLiga", "data": "20/12/2025",
        "casa": {"nome": "Real Madrid", "gols_casa": 2.5, "gols_fora": 1.8, "cantos": 6.5},
        "fora": {"nome": "Sevilla", "gols_casa": 1.4, "gols_fora": 1.0, "cantos": 4.5},
        "over25": 65, "btts": 52, "prob_casa": 70, "prob_empate": 18, "prob_fora": 12
    },
    "bayern x rb leipzig": {
        "liga": "Bundesliga", "data": "20/12/2025",
        "casa": {"nome": "Bayern", "gols_casa": 2.8, "gols_fora": 2.2, "cantos": 6.8},
        "fora": {"nome": "RB Leipzig", "gols_casa": 2.0, "gols_fora": 1.5, "cantos": 5.5},
        "over25": 75, "btts": 65, "prob_casa": 55, "prob_empate": 22, "prob_fora": 23
    },
    "juventus x roma": {
        "liga": "Serie A", "data": "20/12/2025",
        "casa": {"nome": "Juventus", "gols_casa": 1.8, "gols_fora": 1.3, "cantos": 5.5},
        "fora": {"nome": "Roma", "gols_casa": 1.5, "gols_fora": 1.1, "cantos": 5.0},
        "over25": 52, "btts": 48, "prob_casa": 48, "prob_empate": 28, "prob_fora": 24
    },
    "psg x lyon": {
        "liga": "Ligue 1", "data": "20/12/2025",
        "casa": {"nome": "PSG", "gols_casa": 2.6, "gols_fora": 2.0, "cantos": 7.0},
        "fora": {"nome": "Lyon", "gols_casa": 1.8, "gols_fora": 1.3, "cantos": 5.2},
        "over25": 70, "btts": 58, "prob_casa": 65, "prob_empate": 20, "prob_fora": 15
    },
    "newcastle x chelsea": {
        "liga": "Premier League", "data": "20/12/2025",
        "casa": {"nome": "Newcastle", "gols_casa": 1.8, "gols_fora": 1.2, "cantos": 5.8},
        "fora": {"nome": "Chelsea", "gols_casa": 2.1, "gols_fora": 1.5, "cantos": 5.2},
        "over25": 58, "btts": 52, "prob_casa": 35, "prob_empate": 28, "prob_fora": 37
    },
    "inter x napoli": {
        "liga": "Serie A", "data": "20/12/2025",
        "casa": {"nome": "Inter", "gols_casa": 2.2, "gols_fora": 1.6, "cantos": 6.2},
        "fora": {"nome": "Napoli", "gols_casa": 2.0, "gols_fora": 1.4, "cantos": 5.5},
        "over25": 65, "btts": 58, "prob_casa": 45, "prob_empate": 26, "prob_fora": 29
    },
}

def calcular_ev(prob_estimada, odd):
    prob_decimal = prob_estimada / 100
    ev = (prob_decimal * odd) - 1
    return ev * 100

def gerar_analise(jogo_key):
    jogo = JOGOS.get(jogo_key)
    if not jogo:
        return None
    
    casa = jogo["casa"]
    fora = jogo["fora"]
    media_gols = casa["gols_casa"] + fora["gols_fora"]
    media_cantos = casa["cantos"] + fora["cantos"]
    
    linha_gols = "Over 2.5" if media_gols > 2.5 else "Under 2.5"
    prob_gols = jogo["over25"] if media_gols > 2.5 else (100 - jogo["over25"])
    linha_cantos = "Over 9.5" if media_cantos > 9.5 else "Over 8.5" if media_cantos > 8.5 else "Under 8.5"
    
    odd_justa = round(100 / prob_gols, 2) if prob_gols > 0 else 0
    odd_mercado = round(odd_justa * 1.1, 2)
    ev = calcular_ev(prob_gols, odd_mercado)
    
    if ev > 15:
        unidades, confianca = "2.0u", "ALTA"
    elif ev > 8:
        unidades, confianca = "1.5u", "MEDIA-ALTA"
    elif ev > 3:
        unidades, confianca = "1.0u", "MEDIA"
    else:
        unidades, confianca = "0.5u", "BAIXA"
    
    return f"""
RELATORIO DE INTELIGENCIA ESPORTIVA
JOGO: {casa['nome']} x {fora['nome']} | LIGA: {jogo['liga']}

1. CONTEXTO
Partida valida pela {jogo['liga']}, data {jogo['data']}.

2. ANALISE (5 JOGOS)

GOLS
Medias: {casa['nome']} {casa['gols_casa']} gols/jogo em casa | {fora['nome']} {fora['gols_fora']} gols/jogo fora
Media combinada: {media_gols:.1f} gols
Frequencia Over 2.5: {jogo['over25']}%
Veredito: {linha_gols}

CANTOS
Medias: {casa['nome']} {casa['cantos']} cantos/jogo | {fora['nome']} {fora['cantos']} cantos/jogo
Media combinada: {media_cantos:.1f} cantos
Veredito: {linha_cantos}

BTTS (Ambas Marcam)
Probabilidade: {jogo['btts']}%
Veredito: {"BTTS Sim" if jogo['btts'] > 50 else "BTTS Nao"}

3. VALOR
Mercado: {linha_gols}
Probabilidade estimada: {prob_gols}%
Odd justa: {odd_justa}
EV: {ev:.1f}%

4. GESTAO
Recomendacao: {unidades}
Confianca: {confianca}
"""

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Bot de Inteligencia Esportiva\n\n"
        "Comandos:\n"
        "/jogos - Lista jogos disponiveis\n"
        "/melhores - Melhores apostas\n\n"
        "Ou digite o jogo:\n"
        "Exemplo: Tottenham x Liverpool"
    )

async def listar_jogos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = "JOGOS DISPONIVEIS:\n\n"
    for jogo_key, jogo in JOGOS.items():
        msg += f"{jogo['liga']}: {jogo['casa']['nome']} x {jogo['fora']['nome']}\n"
    await update.message.reply_text(msg)

async def melhores_apostas(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = "MELHORES APOSTAS:\n\n"
    apostas = []
    for jogo_key, jogo in JOGOS.items():
        casa, fora = jogo["casa"], jogo["fora"]
        media_gols = casa["gols_casa"] + fora["gols_fora"]
        prob = jogo["over25"] if media_gols > 2.5 else (100 - jogo["over25"])
        odd_justa = 100 / prob if prob > 0 else 0
        ev = calcular_ev(prob, odd_justa * 1.1)
        apostas.append({
            "jogo": f"{casa['nome']} x {fora['nome']}",
            "mercado": "Over 2.5" if media_gols > 2.5 else "Under 2.5",
            "ev": ev, "prob": prob
        })
    apostas.sort(key=lambda x: x["ev"], reverse=True)
    for i, ap in enumerate(apostas[:5], 1):
        msg += f"{i}. {ap['jogo']}\n   {ap['mercado']} | Prob: {ap['prob']}%\n\n"
    await update.message.reply_text(msg)

async def analisar_mensagem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    texto = update.message.text.lower().strip()
    jogo_encontrado = None
    for jogo_key in JOGOS.keys():
        partes = jogo_key.split(" x ")
        if len(partes) == 2:
            t1, t2 = partes
            if t1 in texto or t2 in texto:
                jogo_encontrado = jogo_key
                break
    if jogo_encontrado:
        analise = gerar_analise(jogo_encontrado)
        if analise:
            await update.message.reply_text(analise)
        else:
            await update.message.reply_text("Erro ao gerar analise.")
    else:
        await update.message.reply_text("Jogo nao encontrado. Use /jogos para ver a lista.")

def main():
    logger.info("Iniciando bot...")
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("jogos", listar_jogos))
    app.add_handler(CommandHandler("melhores", melhores_apostas))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, analisar_mensagem))
    logger.info("Bot iniciado!")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
